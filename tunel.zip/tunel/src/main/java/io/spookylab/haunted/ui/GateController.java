package io.spookylab.haunted.ui;

import io.spookylab.haunted.model.PlayerTicket;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class GateController {
    @FXML private TextField fieldName;
    @FXML private TextField fieldSurname;
    @FXML private ComboBox<String> comboCourse;
    @FXML private Label lblHint;

    @FXML
    private void initialize() {
        comboCourse.getItems().setAll("DAM1","DAM2","DAW1","DAW2","SMR1","SMR2");
        lblHint.setText("");
    }

    @FXML
    private void enterIfYouDare(ActionEvent e) {
        try {
            String name    = fieldName.getText()    == null ? "" : fieldName.getText().trim();
            String surname = fieldSurname.getText() == null ? "" : fieldSurname.getText().trim();
            String course  = comboCourse.getValue();

            if (name.isEmpty() || surname.isEmpty() || course == null) {
                lblHint.setText("⚠️ Rellena nombre, apellidos y curso");
                return;
            }

            PlayerTicket ticket = new PlayerTicket(name, surname, course);

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/io/spookylab/haunted/view/roulette.fxml"));
            Parent rouletteRoot = loader.load();

            Object ctrl = loader.getController();
            if (ctrl instanceof RouletteController rc) {
                rc.acceptTicket(ticket);
            }

            Stage stage = (Stage) ((Control) e.getSource()).getScene().getWindow();
            Scene scene = new Scene(rouletteRoot);
            scene.getStylesheets().add(getClass().getResource("/io/spookylab/haunted/css/spooky.css").toExternalForm());
            stage.setScene(scene);
            stage.centerOnScreen();

        } catch (Exception ex) {
            ex.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Fallo al abrir la ruleta:\n" + ex.getMessage()).showAndWait();
        }
    }
}
