package io.spookylab.haunted.ui;

import io.spookylab.haunted.model.PlayerTicket;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.WritableImage;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.scene.text.Font;
import javafx.util.Duration;

import java.util.List;
import java.util.Random;

public class RouletteController {
    @FXML private ImageView wheelView;
    @FXML private Button btnSpin;
    @FXML private Label lblOutcome;
    @FXML private Label lblDetail;

    private final Random rng = new Random();

    public void acceptTicket(PlayerTicket t) {
        // Puedes usar los datos si quieres personalizar el título o el resultado
    }

    @FXML
    private void initialize() {
        lblOutcome.setText("");
        lblDetail.setText("");

        // Dibuja ruleta naranja/morado con textos grandes
        int size = 520;
        Canvas canvas = new Canvas(size, size);
        GraphicsContext g = canvas.getGraphicsContext2D();

        double pad = 12;
        double w = size - 2 * pad, h = size - 2 * pad;

        // Colores Halloween 🎃
        Color ORANGE = Color.web("#f59e0b");
        Color PURPLE = Color.web("#7c3aed");

        // Dos mitades
        g.setFill(ORANGE);
        g.fillArc(pad, pad, w, h, 90, 180, ArcType.ROUND);   // TRUCO
        g.setFill(PURPLE);
        g.fillArc(pad, pad, w, h, 270, 180, ArcType.ROUND);  // TRATO

        // División y punto central
        g.setStroke(Color.web("#1f1d24"));
        g.setLineWidth(6);
        g.strokeLine(size / 2.0, pad, size / 2.0, pad + h);
        g.setFill(Color.web("#1f1d24"));
        g.fillOval(size / 2.0 - 5, size / 2.0 - 5, 10, 10);

        // Texto TRUCO / TRATO centrado dentro
        Font f = Font.font("Segoe UI", 38);
        g.setFont(f);
        g.setFill(Color.WHITE);

        // Usamos una medida estimada del ancho del texto (segura)
        double t1w = 7.5 * "TRUCO".length();
        double t2w = 7.5 * "TRATO".length();

        g.fillText("TRUCO", pad + w * 0.25 - t1w, size / 2.0 + 12);
        g.fillText("TRATO", pad + w * 0.75 - t2w, size / 2.0 + 12);

        // Pasa la imagen al ImageView
        SnapshotParameters sp = new SnapshotParameters();
        sp.setFill(Color.TRANSPARENT);
        WritableImage img = new WritableImage(size, size);
        canvas.snapshot(sp, img);
        wheelView.setImage(img);
        wheelView.setPreserveRatio(true);
        wheelView.setFitWidth(420);
    }

    @FXML
    private void spin() {
        btnSpin.setDisable(true);
        lblOutcome.setText("");
        lblDetail.setText("");

        double turns = 3 + rng.nextDouble() * 2; // 3..5 vueltas
        double degrees = turns * 360 + rng.nextInt(360);

        RotateTransition rt = new RotateTransition(Duration.millis(2800 + rng.nextInt(600)), wheelView);
        rt.setByAngle(degrees);
        rt.setInterpolator(Interpolator.EASE_OUT);
        rt.setOnFinished(ev -> {
            boolean isTrick = rng.nextBoolean();
            String title = isTrick ? "TRUCO" : "TRATO";
            String detail = isTrick
                    ? List.of("Imita un zombi 10s", "Ríe como bruja 3 veces", "Camina como Frankenstein", "Cuenta un mini-susto").get(rng.nextInt(4))
                    : List.of("Caramelo virtual ", "Elige la música", "Permiso para pista ", "Exención mini-tarea").get(rng.nextInt(4));

            lblOutcome.setText(title);
            lblOutcome.getStyleClass().removeAll("trick", "treat");
            lblOutcome.getStyleClass().add(isTrick ? "trick" : "treat");
            lblDetail.setText(detail);

            new Alert(Alert.AlertType.INFORMATION, title + " — " + detail).showAndWait();
            btnSpin.setDisable(false);
        });
        rt.play();
    }
}
