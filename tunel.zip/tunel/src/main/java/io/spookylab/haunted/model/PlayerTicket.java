package io.spookylab.haunted.model;

public class PlayerTicket {
    private final String name;
    private final String surname;
    private final String course;
    public PlayerTicket(String name,String surname,String course){
        this.name=name;this.surname=surname;this.course=course;
    }
    public String getName(){return name;}
    public String getSurname(){return surname;}
    public String getCourse(){return course;}
    public String getFullName(){return name+" "+surname;}
}
