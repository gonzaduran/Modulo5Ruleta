package io.spookylab.haunted.ui;

import io.spookylab.haunted.model.PlayerTicket;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;

import java.io.IOException;

public class GateController {
    @FXML private AnchorPane root;
    @FXML private TextField fieldName;
    @FXML private TextField fieldSurname;
    @FXML private ComboBox<String> comboCourse;
    @FXML private Button btnEnter;
    @FXML private Label lblHint;

    private AudioClip ambience;

    @FXML
    private void initialize() {
        comboCourse.getItems().addAll("DAM1","DAM2","DAW1","DAW2","SMR1","SMR2");
        lblHint.setText("");
        try {
            root.setStyle("-fx-background-image: url('/io/spookylab/haunted/assets/bg.jpg'); -fx-background-size: cover;");
        } catch (Exception ignored) {}
        try {
            ambience = new AudioClip(getClass().getResource("/io/spookylab/haunted/assets/fog.mp3").toExternalForm());
            ambience.setCycleCount(AudioClip.INDEFINITE);
            ambience.setVolume(0.15);
            ambience.play();
        } catch (Exception ignored) {}
    }

    @FXML
    private void enterIfYouDare(ActionEvent e) throws IOException {
        String name = fieldName.getText() != null ? fieldName.getText().trim() : "";
        String surname = fieldSurname.getText() != null ? fieldSurname.getText().trim() : "";
        String course = comboCourse.getValue();

        if (name.isEmpty() || surname.isEmpty() || course == null) {
            lblHint.setText("⚠️ Rellena nombre, apellidos y curso");
            if (!lblHint.getStyleClass().contains("error")) lblHint.getStyleClass().add("error");
            return;
        }

        PlayerTicket ticket = new PlayerTicket(name, surname, course);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/io/spookylab/haunted/view/roulette.fxml"));
        Parent rouletteRoot = loader.load();
        RouletteController controller = loader.getController();
        controller.acceptTicket(ticket);

        Stage stage = (Stage) root.getScene().getWindow();
        Scene scene = new Scene(rouletteRoot);
        scene.getStylesheets().add(getClass().getResource("/io/spookylab/haunted/css/spooky.css").toExternalForm());
        stage.setScene(scene);
        stage.centerOnScreen();
    }
}
