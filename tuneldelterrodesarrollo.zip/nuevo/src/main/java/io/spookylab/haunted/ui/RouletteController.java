package io.spookylab.haunted.ui;

import io.spookylab.haunted.model.PlayerTicket;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.util.List;
import java.util.Random;

public class RouletteController {
    @FXML private Label lblHeader;
    @FXML private ImageView wheelView;
    @FXML private Button btnSpin;
    @FXML private Label lblOutcome;
    @FXML private Label lblDetail;

    private final Random rng = new Random();
    private PlayerTicket ticket;

    private final List<String> tricks = List.of(
            "Imita a un zombi durante 10s",
            "Ríe como bruja 3 veces",
            "Camina como Frankenstein hasta la puerta",
            "Cuenta un mini-susto a la clase"
    );

    private final List<String> treats = List.of(
            "Caramelo virtual 🍬",
            "Elige la próxima música",
            "Permiso para pedir pista 😜",
            "Exención de una micro-tarea"
    );

    public void acceptTicket(PlayerTicket ticket) {
        this.ticket = ticket;
        lblHeader.setText(ticket.getFullName() + " — " + ticket.getCourse());
    }

    @FXML
    private void initialize() {
        lblOutcome.setText("");
        lblDetail.setText("");
        try {
            wheelView.setImage(new Image(getClass().getResourceAsStream("/io/spookylab/haunted/assets/wheel.png")));
            wheelView.setPreserveRatio(true);
        } catch (Exception ignored) {}
    }

    @FXML
    private void spin() {
        btnSpin.setDisable(true);
        lblOutcome.setText("");
        lblDetail.setText("");

        double turns = 3 + rng.nextDouble() * 2; // 3..5 vueltas
        double degrees = turns * 360 + rng.nextInt(360);

        RotateTransition rt = new RotateTransition(Duration.millis(2800 + rng.nextInt(600)), wheelView);
        rt.setByAngle(degrees);
        rt.setInterpolator(Interpolator.EASE_OUT);
        rt.setOnFinished(ev -> {
            boolean isTrick = rng.nextBoolean();
            String title = isTrick ? "TRUCO" : "TRATO";
            String detail = isTrick ? tricks.get(rng.nextInt(tricks.size())) : treats.get(rng.nextInt(treats.size()));
            lblOutcome.setText(title);
            lblOutcome.getStyleClass().removeAll("trick","treat");
            lblOutcome.getStyleClass().add(isTrick ? "trick" : "treat");
            lblDetail.setText(detail);

            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setTitle("Resultado");
            a.setHeaderText(null);
            a.setContentText(title + " — " + detail);
            a.showAndWait();

            btnSpin.setDisable(false);
        });
        rt.play();
    }
}
