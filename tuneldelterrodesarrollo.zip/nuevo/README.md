# Haunted Tunnel — Trick/Treat Roulette (JavaFX)

Mini‑app (JavaFX + FXML) con dos pantallas:

1. **Puerta del Túnel**: recoge _Nombre_, _Apellidos_, _Curso_ (DAM1/DAM2/DAW1/DAW2/SMR1/SMR2) con validación.
2. **Ruleta**: animación de giro y resultado 50/50 **TRUCO**/**TRATO** mostrando nombre completo y curso arriba.

## Ejecutar (Maven)
```bash
mvn -q javafx:run
```

## Recursos
Coloca en `src/main/resources/io/spookylab/haunted/assets/`:
- `bg.jpg` (fondo opcional)
- `wheel.png` (imagen ruleta 50/50)
- `fog.mp3` (ambiente opcional)

## Capturas
Añade `gate.png` y `roulette.png`.
